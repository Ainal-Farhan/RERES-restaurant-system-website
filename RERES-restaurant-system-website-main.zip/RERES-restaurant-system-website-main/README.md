"# RERES-restaurant-system-website" 
# RERES-restaurant-system-website

<table>
  <thead>
    <tr>
      <th colspan="2">System environments</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Application Type</th>
      <td>web application</td>
    </tr>
    <tr>
      <th>Languages</th>
      <td>Java, JSP, CSS</td>
    </tr>
    <tr>
      <th>Build Tool</th>
      <td>ANT</td>
    </tr>
    <tr>
      <th>JAVA EE Version</th>
      <td>JAVA EE 7 Web</td>
    </tr>
    <tr>
      <th>JDK</th>
      <td>JDK 8</td>
    </tr>
    <tr>
      <th>server</th>
      <td>Glassfish server 4.1.1</td>
    </tr>
    <tr>
      <th>Framework</th>
      <td>None</td>
    </tr>
    <tr>
      <th>IDE</th>
      <td>Apache netbeans 12.0, netbeans 8.2</td>
    </tr>
  </tbody>
</table>
